package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.projecttwo.WeightDB;


import java.util.List;

public class HomeActivity extends AppCompatActivity {
    //UI Components
    private GridLayout gridLayout;
    //initialize database
    private UserDB userDB;
    private WeightDB weightDB;
    private TextView goalTextView;
    private EditText goalEditText;
    private Button updateGoalButton;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        // UI Elements
        goalTextView = findViewById(R.id.Goal);
        goalEditText = findViewById(R.id.goalInput);
        updateGoalButton = findViewById(R.id.btnUpdateGoal);
        gridLayout = findViewById(R.id.gridLayout);

        //initialize DB
        weightDB = new WeightDB(this);
        userDB = new UserDB(this);

        // Get CURRENT user ID passed from MainActivity
        int userId = getIntent().getIntExtra("USER_ID", -1);
//        todo getting NULL userid - Research and FIX- DONE!
        if (userId == -1) {
            Toast.makeText(this, "User ID not found. Please log in again." + userId, Toast.LENGTH_SHORT).show();
            finish(); // End activity if no user ID is passed
            return;
        }

        // Show the current goal weight for the CURRENT user
        String currentGoal = weightDB.getGoalWeight(String.valueOf(userId));
        goalTextView.setText("Goal: " + currentGoal + " lbs");



//        // Set the current goal weight
//        String currentGoal = weightDB.getGoalWeight();
//        goalTextView.setText("Goal: " + currentGoal + " lbs");

        // Listener for updating the goal weight
        updateGoalButton.setOnClickListener(v -> {
            String newGoal = goalEditText.getText().toString().trim(); //trim to clean up user input
            if (!newGoal.isEmpty()) {
                weightDB.updateGoalWeight(String.valueOf(userId), newGoal);
                goalTextView.setText("Goal: " + newGoal + " lbs");
                Toast.makeText(HomeActivity.this, "Goal updated!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(HomeActivity.this, "Please enter a valid goal weight.", Toast.LENGTH_SHORT).show();
            }
        });

        // populate grid with data from database
        populateGrid(String.valueOf(userId));

        // Button for Logging Weight
        Button btnLogWeight = findViewById(R.id.btnLogWeight);
        btnLogWeight.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, LogWeight.class);
            intent.putExtra("USER_ID", userId); // Pass user ID to the next activity
            startActivity(intent);
        });


        // Button for sending SMS
        findViewById(R.id.btnSendSms).setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, SMSActivity.class);
            intent.putExtra("USER_ID", userId); // Pass user ID to the SMS activity
            startActivity(intent);
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the grid when coming back to this activity screen (for after Log weight)
        int userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID not found. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        populateGrid(String.valueOf(userId));
    }

    private void populateGrid(String userId) {
        int headerCount = 3; // The number of header views (defined in XML)
        while (gridLayout.getChildCount() > headerCount) {
            gridLayout.removeViewAt(headerCount);
        }

        // get all weight entries from the database
        List<com.zybooks.projecttwo.WeightDB.WeightEntry> weightList = weightDB.getAllWeights(userId);

        // add each weight entry to the grid layout
        for (com.zybooks.projecttwo.WeightDB.WeightEntry entry : weightList) {
            addRow(entry.getId(), entry.getDate(), entry.getWeight());
        }
    }

    private void addRow(int id, String date, String weight) {
        // ensure the header row is not lost (headers are in row 0, 3 columns)
        int rowIndex = gridLayout.getChildCount() / 3;

        // todo Save values in grid
        // Create TextView for the date
        TextView dateView = new TextView(this);
        dateView.setText(date);

        // Create TextView for the weight
        TextView weightView = new TextView(this);
        weightView.setText(weight);
        weightView.setPadding(8, 0, 0, 0);

        // Create ImageButton for deletion
        ImageButton deleteButton = new ImageButton(this);
        deleteButton.setImageResource(R.drawable.twotone_delete_24);
        deleteButton.setBackground(null);
        // allow for deleting a row based on id
        deleteButton.setOnClickListener(v -> deleteRow(id));


        //set format for values
        GridLayout.LayoutParams dateParams = new GridLayout.LayoutParams(
                GridLayout.spec(rowIndex), GridLayout.spec(0));
        dateParams.width = 0;
        dateParams.columnSpec = GridLayout.spec(0, 1, 4f);
        gridLayout.addView(dateView, dateParams);

        GridLayout.LayoutParams weightParams = new GridLayout.LayoutParams(
                GridLayout.spec(rowIndex), GridLayout.spec(1));
        weightParams.width = 0;
        weightParams.columnSpec = GridLayout.spec(1, 1, 4f);
        gridLayout.addView(weightView, weightParams);

        GridLayout.LayoutParams deleteParams = new GridLayout.LayoutParams(
                GridLayout.spec(rowIndex), GridLayout.spec(2));
        deleteParams.width = 0;
        deleteParams.columnSpec = GridLayout.spec(2, 1, 2f);
        gridLayout.addView(deleteButton, deleteParams);
    }

    private void deleteRow(int id) {
        // delete the chosen row from the database
        int rowsDeleted = weightDB.deleteWeight(id);
        if (rowsDeleted > 0) {
            Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
        }

//        refresh the grid to remove row
        int userId = getIntent().getIntExtra("USER_ID", -1);
        populateGrid(String.valueOf(userId));

    }
}
