package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LogWeight extends AppCompatActivity {

    private com.zybooks.projecttwo.WeightDB weightDB;
    private int userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_log_weight);

//        userId = getIntent().getStringExtra("USER_ID");


        // Fetch user ID passed from HomeActivity
        int userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID not found. Please log in again.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // get database
        weightDB = new com.zybooks.projecttwo.WeightDB(this);


        //UI Elements
        //login screen
        EditText newDate = findViewById(R.id.newDate);
        EditText newWeight = findViewById(R.id.newWeight);
        Button btnLogWeight = findViewById(R.id.btnLogWeight);

        //listener for login button
        btnLogWeight.setOnClickListener(view -> {
            String date = newDate.getText().toString().trim();
            String weight = newWeight.getText().toString().trim();
            // Validate input
            if (date.isEmpty() || weight.isEmpty()) {
                Toast.makeText(LogWeight.this, "Please enter both date and weight.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Insert data into database
            long rowId = weightDB.insertWeight(String.valueOf(userId), date, weight);
            if (rowId > 0) {
                Toast.makeText(LogWeight.this, "Weight logged successfully!", Toast.LENGTH_SHORT).show();
                // Navigate back to HomeActivity
                Intent intent = new Intent(LogWeight.this, HomeActivity.class);
                intent.putExtra("USER_ID", userId); // Pass the correct userId back
                startActivity(intent);
            } else {
                Toast.makeText(LogWeight.this, "Failed to log weight.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}