package com.zybooks.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class UserDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int DATABASE_VERSION = 2;

    //define table and column names
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "user_id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

//    initiate user db
    public UserDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    //create the user db with 3 cols,
    //      User Id: Auto incrementing numerical primary key
    //      username: store string username
    //      password: store string password
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        COL_PASSWORD + " TEXT NOT NULL)"
        );
    }


    public long createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        return db.insert(TABLE_USERS, null, values);
    }

//    *** todo FIX THIS LOGIC??? CONFIRMED WORKING CORRECTLY!
    public int getUserId(String username) {
        //connect to db
        SQLiteDatabase db = this.getReadableDatabase();
        //define lookup query with placeholder username that will be replaced
        String query = "SELECT " + COL_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(0); // first column as int
            cursor.close();
            return userId;
        }

        if (cursor != null) {
            cursor.close();
        }

        return -1; // Return -1 if no user is found
    }

    // get userId and validate combined
    public int validateAndFetchUserId(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COL_USER_ID +
                " FROM " + TABLE_USERS +
                " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(0);
            cursor.close();
            return userId;
        }

        if (cursor != null) {
            cursor.close();
        }

        return -1; // Return -1 if credentials are invalid
    }

    @Override
    //handle schema changes in testing
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //testing
    }



    // Check if user exists and validate credentials
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                null,
                COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{username, password},
                null, null, null);

        boolean isValid = (cursor != null && cursor.moveToFirst());
        if (cursor != null) {
            cursor.close();
        }

        return isValid;
    }

    // Check if username already exists
    public boolean isUsernameTaken(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                null,
                COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null);

        boolean exists = (cursor != null && cursor.moveToFirst());
        if (cursor != null) {
            cursor.close();
        }
        return exists;
    }


}
