package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private UserDB userDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // initialize user credentials database
        userDB = new UserDB(this);

        //UI Elements
        //login screen
        EditText Username = findViewById(R.id.Username);
        EditText Password = findViewById(R.id.Password);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreateAccount = findViewById(R.id.btnCreateAccount);



        //listener for button todo **LOGIN**
        btnLogin.setOnClickListener(view -> {
            String username = Username.getText().toString().trim();
            String password = Password.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Username and Password required.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate credentials and fetch User ID
            int userId = userDB.validateAndFetchUserId(username, password);
            if (userId != -1) {
                Toast.makeText(MainActivity.this, "Login Successful! User ID: " + userId, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
            }
        });

        //listener for create account button
        btnCreateAccount.setOnClickListener(view -> {
            String username = Username.getText().toString().trim();
            String password = Password.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Username and Password required.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if username exists
            if (userDB.isUsernameTaken(username)) {
                Toast.makeText(MainActivity.this, "Username already exists. Choose a different one.", Toast.LENGTH_SHORT).show();
            } else {
                long newUserId = userDB.createUser(username, password);
                if (newUserId != -1) {
                    Toast.makeText(MainActivity.this, "Account created successfully! You may now login! User ID: " + newUserId, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Error creating account. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}