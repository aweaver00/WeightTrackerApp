package com.zybooks.projecttwo;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
public class WeightDB extends SQLiteOpenHelper {

    // database info
    private static final String DATABASE_NAME = "weights.db";
    private static final int DATABASE_VERSION = 2;

    // table info
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COL_ID = "_id";
    public static final String COL_USER_ID = "user_id"; // added user id
    public static final String COL_DATE = "date";
    public static final String COL_WEIGHT = "weight";

    public WeightDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    // Add goal weight column and functionality
    public static final String TABLE_GOAL = "goal";
    public static final String COL_GOAL_WEIGHT = "goal_weight";


    @Override
    public void onCreate(SQLiteDatabase db) {
        // LOG WEIGHTS table
        db.execSQL(
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USER_ID + " TEXT NOT NULL, " + // added user ID (w_user_id)
                        COL_DATE + " TEXT NOT NULL, " +
                        COL_WEIGHT + " TEXT NOT NULL)"
        );

        // GOAL weight table
        db.execSQL(
                "CREATE TABLE " + TABLE_GOAL + " (" +
                        COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USER_ID + " TEXT NOT NULL, " + //  added user ID
                        COL_GOAL_WEIGHT + " TEXT NOT NULL)"
        );



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop both tables if they exist and recreate them
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        onCreate(db);
    }


    // Update the goal weight
    public void updateGoalWeight(String userId, String newGoal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_GOAL_WEIGHT, newGoal);

        int rows = db.update(TABLE_GOAL, values, COL_USER_ID + " = ?", new String[]{userId});
        if (rows == 0) {
            // Insert new goal if not found
            values.put(COL_USER_ID, userId);
            db.insert(TABLE_GOAL, null, values);
        }
    }

    // Get the current goal weight
    public String getGoalWeight(String userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GOAL,
                                new String[]{COL_GOAL_WEIGHT},
                        COL_USER_ID + " = ?",
                                new String[]{userId},
                        null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            String goal = cursor.getString(cursor.getColumnIndexOrThrow(COL_GOAL_WEIGHT));
            cursor.close();
            return goal;
        }
        return "???"; // Default if no value input by user
    }


    // add a new weight entry
    public long insertWeight(String userId, String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_ID, userId);
        values.put(COL_DATE, date);
        values.put(COL_WEIGHT, weight);
        return db.insert(TABLE_WEIGHTS, null, values);
    }

    // return all weight entries **UPDATE** Show ONLY the data for the user logged in
    public List<WeightEntry> getAllWeights(String userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<WeightEntry> weightList = new ArrayList<>();

        Cursor cursor = db.query(TABLE_WEIGHTS,
                null,
                COL_USER_ID + " = ?",
                new String[]{userId},
                null, null, COL_ID + " DESC");

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATE));
                String weight = cursor.getString(cursor.getColumnIndexOrThrow(COL_WEIGHT));
                weightList.add(new WeightEntry(id, date, weight));
            }
            cursor.close();
        }

        return weightList;
    }

    // delete a weight entry by ID
    public int deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_WEIGHTS, COL_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // helper class for entries
    public static class WeightEntry {
        private int id;
        private String date;
        private String weight;

        public WeightEntry(int id, String date, String weight) {
            this.id = id;
            this.date = date;
            this.weight = weight;
        }

        public int getId() {
            return id;
        }

        public String getDate() {
            return date;
        }

        public String getWeight() {
            return weight;
        }
    }
}
