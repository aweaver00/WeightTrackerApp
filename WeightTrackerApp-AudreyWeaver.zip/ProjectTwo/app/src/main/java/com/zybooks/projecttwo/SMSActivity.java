package com.zybooks.projecttwo;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.Manifest;

public class SMSActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 1;

    private EditText phoneNumber;
    private EditText messageBody;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        phoneNumber = findViewById(R.id.phoneNumber);
        messageBody = findViewById(R.id.messageBody);
        Button sendSmsButton = findViewById(R.id.sendSmsButton);

        sendSmsButton.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(SMSActivity.this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // get permission
                ActivityCompat.requestPermissions(SMSActivity.this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            } else {
                // permission was already granted
                sendSms();
            }
        });


        // listener for when SMS CANCEL Button is clicked
        findViewById(R.id.cancelButton).setOnClickListener(view -> {
            Intent intent = new Intent(SMSActivity.this, HomeActivity.class);
            startActivity(intent);
        });

    }

    private void sendSms() {
        String phone = phoneNumber.getText().toString().trim();
        String message = messageBody.getText().toString().trim();

        if (phone.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "Enter phone number and message.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, message, null, null);
            Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS message: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

        // listener for when SMS  Button is clicked
        findViewById(R.id.sendSmsButton).setOnClickListener(view -> {
            Intent intent = new Intent(SMSActivity.this, HomeActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSms();
            } else {
                Toast.makeText(this, "Permission denied. Could not send SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}